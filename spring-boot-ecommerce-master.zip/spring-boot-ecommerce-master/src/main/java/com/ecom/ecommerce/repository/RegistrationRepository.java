package com.ecom.ecommerce.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ecom.ecommerce.model.Admin;

public interface RegistrationRepository extends JpaRepository<Admin, Integer>{

	public Admin findByEmailId(String emailId);

	public Admin findByEmailIdAndPassword(String emailiId,String password);
}
